/*
 * Author: Ireoluwa
 * Created on June 22, 2024, 2:19 PM
 * Purpose: sum of two numbers
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Mathematical, Scientific, Conversions

//Higher Dimensions go here. No Variables

//Function Prototypes

//Execution Begins here

int main(int argc, char** argv) {
    //Setting the random number seed
    
    //Declaring Variables
   unsigned short a, b, total;
   
    //Initialize Variables
    a = 100;
    b = 50;
    
    //Processing/Mapping Inputs to Outputs
    total = a + b;
    
    //Displaying Input/Output Information
    cout << "The sum of " << a << " and " << b <<  " is " << total << endl;
 
    //Exiting stage left/right
    return 0;
}

