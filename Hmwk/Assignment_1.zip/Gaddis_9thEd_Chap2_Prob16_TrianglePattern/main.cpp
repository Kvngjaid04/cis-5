/*
 * Author: Ireoluwa
 * Created on June 20, 2024, 5:00 PM
 * Purpose: Triangle problem
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Mathematical, Scientific, Conversions

//Higher Dimensions go here. No Variables

//Function Prototypes

//Execution Begins here

int main(int argc, char** argv) {
    //Setting the random number seed
    
    //Declaring Variables
    
    //Initialize Variables
    
    //Processing/Mapping Inputs to Outputs
    
    //Displaying Input/Output Information
    cout << "   *" << endl;
    cout << "  ***" << endl;
    cout << " *****" << endl;
    cout << "*******" << endl;
    //Exiting stage left/right
    return 0;
}

