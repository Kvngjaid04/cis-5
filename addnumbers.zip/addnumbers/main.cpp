/*
 * Author: Ireoluwa
 * Created on June 18, 2024, 12:19 PM
 * Purpose: Hello world
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Mathematical, Scientific, Conversions

//Higher Dimensions go here. No Variables

//Function Prototypes

//Execution Begins here

int main(int argc, char** argv) {
    //Setting the random number seed
    
    //Declaring Variables
    short int a, b, c;
    
    //Initialize Variables
    a = 10000; // 2 Byte variable
    b = 30000; // 2 Byte Variable
    
    //Processing/Mapping Inputs to Outputs
    c = b + a;
    //Displaying Input/Output Information
    cout << a << " + " << b << " = " << c << endl ;
    
    //Exiting stage left/right
    return 0;
}

